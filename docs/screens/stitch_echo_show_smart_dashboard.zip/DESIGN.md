---
name: Ambient Smart Display Interface
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#ffd799'
  on-secondary: '#432c00'
  secondary-container: '#feb300'
  on-secondary-container: '#6a4800'
  tertiary: '#e4edff'
  on-tertiary: '#213145'
  tertiary-container: '#c1d2ec'
  on-tertiary-container: '#4a5a70'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#ffdeac'
  secondary-fixed-dim: '#ffba38'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#604100'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  clock-display:
    fontFamily: Space Grotesk
    fontSize: 112px
    fontWeight: '700'
    lineHeight: 100px
    letterSpacing: -0.04em
  clock-display-mobile:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 68px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 30px
  metric-large:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-numeric:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.75rem
  margin: 1.75rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style
The brand personality is calm, intelligent, non-intrusive, and glanceable. Designed for an 8-inch smart display context (such as an Echo Show 8 on a bedside table, kitchen island, or desk), the UI balances environmental presence with zero-friction utility. The interface acts as a silent digital layer in the physical room: unobtrusive at rest, ultra-legible when referenced from across the room (10+ feet), and instantly responsive to close-range touch.

The visual style blends dark ambient minimalism with refined glassmorphism and tactile hardware frame framing:
- **Atmospheric Depth:** Deep slate charcoal and near-black navy layers that recede naturally into domestic lighting conditions without emitting excessive glare.
- **Micro-Glass Surfaces:** Ultra-subtle translucent panels (6%–8% white opacities) paired with fine, diffused ambient glows to segment information without visual weight.
- **Hardware Integration:** The software canvas is contained within an authentic physical framing metaphor: soft pebble-radiused device bezels, micro-camera privacy shutter cues, sensor arrays, and fabric-textured desktop kickstand anchors.

## Colors
The palette is engineered for high contrast under variable indoor luminance—from direct morning daylight to dim nightstand visibility.

- **Primary (`#00E5FF` - Vivid Cyan):** Applied to active states, glanceable weather symbols, connectivity cues, interactive toggles, and critical ambient alerts. Provides maximum contrast against charcoal backdrops.
- **Secondary (`#FFB300` - Radiant Amber):** Reserved for environmental warmth, solar/heat tracking metrics, sunset indicators, active timers, and alarms.
- **Tertiary (`#64748B` - Slate Muted):** Used for non-essential framing, secondary metadata, unit labels, inactive track scrubbers, and divider strokes.
- **Neutral Base (`#0B0F19` - Deep Obsidian Navy):** The true foundation color of the canvas, avoiding sterile pure black to maintain richness and depth under screen backlighting.

### Surface System
- **Base Canvas:** `#0B0F19`
- **Surface Ambient (Elevated Card):** `rgba(255, 255, 255, 0.06)` with backdrop blur `24px`
- **Surface Active / Focused:** `rgba(255, 255, 255, 0.12)` with backdrop blur `32px`
- **Border Stroke Subtle:** `rgba(255, 255, 255, 0.08)`
- **Border Stroke Focused:** `rgba(0, 229, 255, 0.4)`
- **Text Primary:** `#F8FAFC`
- **Text Secondary:** `rgba(248, 250, 252, 0.65)`
- **Text Tertiary / Disabled:** `rgba(248, 250, 252, 0.35)`

## Typography
Typography is split strictly into display/numerical telemetry and contextual reading.

- **Primary Display & Data (`Space Grotesk`):** Chosen for its crisp, geometric clarity and distinct tabular figures (`font-variant-numeric: tabular-nums`). Essential for time readouts, weather values, countdown timers, and hardware telemetry without jitter when figures transition.
- **Contextual Copy & Content (`Hanken Grotesk`):** Clean, neutral sans-serif designed for legibility at oblique angles and lower light. Used for calendar entries, smart home node states, music titles, and voice interaction feedback.

### Usage Rules
- All clock readouts and temperature widgets must enable tabular numerals to ensure stable width layout across digital ticks.
- `label-caps` must always be rendered in `text-transform: uppercase` with wide tracking to retain readability at small sizes on the smart display screen.

## Layout & Spacing
The layout follows an edge-to-edge landscape canvas optimized for the Echo Show 8 (1280x800 native resolution at 16:10 aspect ratio), reflowing smoothly into mobile viewport companion states.

### Primary Display Layout (16:10 Landscape Grid)
- **Grid Architecture:** 6-column fluid grid system on landscape viewports with `1.75rem` (28px) screen margins and `1rem` (16px) gutters.
- **Asymmetric Split:** 
  - Left Hero Zone (Columns 1–3): Anchored clock, environmental temperature readout, and core status indicators.
  - Right Widget Zone (Columns 4–6): Scrollable or swipeable card stack containing contextual modules (Next Calendar Event, Smart Home Quick Toggles, Media Player, and Multi-Day Forecast).
- **Reflow to Mobile/Portrait:** Collapses to a single-column stacked vertical layout with `1rem` margins and `0.75rem` gutters. Primary glanceable time and current conditions persist pinned at the top.

## Elevation & Depth
Elevation mimics back-lit optical glass suspended directly over deep fluid fields. Avoid physical dropped shadow artifacts; instead, rely on luminance grading, optical refraction, and boundary luminescence.

### Elevation Hierarchy
- **Level 0 (Hardware Canvas):** Matte dark navy `#0B0F19` backdrop with subtle organic radial gradients (e.g., faint ambient glow radiating from current music album art or weather conditions).
- **Level 1 (Ambient Cards & Modules):** `background: rgba(255, 255, 255, 0.06)`, `backdrop-filter: blur(24px)`, framed with `border: 1px solid rgba(255, 255, 255, 0.08)`. Subtle top-lit highlight (`box-shadow: inset 0 1px 1px 0 rgba(255, 255, 255, 0.1)`).
- **Level 2 (Active & Interacted Cards):** `background: rgba(255, 255, 255, 0.12)`, `backdrop-filter: blur(36px)`. Border transitions to `rgba(0, 229, 255, 0.35)`. Soft cyan ambient halo: `box-shadow: 0 12px 32px -4px rgba(0, 229, 255, 0.12), inset 0 1px 1px 0 rgba(255, 255, 255, 0.2)`.
- **Level 3 (Voice Ingestion HUD / Modal Overlays):** Full-bleed atmospheric glass overlay with higher blur (`backdrop-filter: blur(48px)`), framed with bottom ambient edge lighting that pulses synchronously with speech recognition.

## Shapes
The shape system matches the industrial design geometry of the Echo Show 8.

- **Standard Containers:** Cards, media panels, and glance blocks utilize `1rem` (`rounded-lg`) corner radii to mirror the gentle curvature of the device display bezel.
- **Hardware Enclosure Metaphor:** The outermost visual wrapper represents the physical device chassis with an ultra-soft `2rem` to `2.5rem` exterior radius, top sensor/mic array notch, and bottom desktop base geometry.
- **Interactive Controls & Badges:** Toggles, status tags, and control pills use high-curvature stadium pill geometry (`9999px`) to invite immediate touch interaction and distinguish interactive nodes from static display panels.

## Components

### Hardware Enclosure Shell
- **Chassis Frame:** Soft, rounded charcoal perimeter (`#1E222D`) with subtle inner bezel highlight and perimeter matte finish.
- **Top Sensor Bar:** Integrated microphone cutouts, light sensor aperture, and privacy shutter switch for the camera.
- **Desktop Stand:** Subtle perspective base beneath the frame featuring woven acoustic fabric texture representation (`#161A23`) anchoring the smart screen to the surface.

### Glanceable Clock & Weather Module
- **Time Readout:** Monolithic `clock-display` typography in tabular figures. Colon separator pulses gently at 1 Hz in passive mode.
- **Micro-Condition Strip:** Temperature rendered in `metric-large` with superscript `°F` or `°C` followed by a glowing cyan weather icon and amber precipitation probability badge.

### Ambient Glass Cards
- Built using Level 1 elevation: translucent `rgba(255, 255, 255, 0.06)` base with `1px` subtle rim lighting.
- Inner padding: `1.5rem` (`space-lg`) on smart display; `1rem` on mobile reflow.
- Cards maintain fixed minimum touch target dimensions of 48x48px for any embedded interactive hitboxes.

### Interactive Quick Toggles (Smart Home Nodes)
- **Container:** Rounded pill or square squircle (`rounded-lg`) with Level 1 glass.
- **Active State:** Cyan surface glow with icon rendered in high-luminance `#00E5FF`.
- **Inactive State:** Low opacity tertiary tone `rgba(255, 255, 255, 0.04)` with muted white iconography.

### Media Player Panel
- Album artwork dynamically colors the backdrop through a soft 200px blurred ambient backlight.
- Tabular time scrubber track with `#00E5FF` fill and rounded thumb.
- High-contrast touch controls: 56px primary Play/Pause circular touch target with semi-translucent fill.

### Voice Activity Strip (Alexa Presence)
- Bottom-docked responsive ambient light bar spanning the full width of the screen.
- Active listening: dynamic gradient shifting between Vivid Cyan (`#00E5FF`) and Deep Indigo (`#2563EB`) with fluid sinusoidal pulse animation.